
async function register(){
  let email=document.getElementById('email').value;
  let r=await fetch('/api/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email})});
  document.getElementById('out').innerText=await r.text();
}

async function createMod(){
  let name=document.getElementById('name').value;
  let id=document.getElementById('mid').value;
  let r=await fetch('/api/create_mod',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,id,owner:"user"})});
  document.getElementById('out').innerText=await r.text();
}

async function ai(){
  let prompt=document.getElementById('prompt').value;
  let r=await fetch('/api/ai_generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt})});
  document.getElementById('out').innerText=await r.text();
}

async function loadMods(){
  let r=await fetch('/api/mods');
  document.getElementById('out').innerText=await r.text();
}
