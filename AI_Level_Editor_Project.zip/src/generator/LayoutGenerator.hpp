// Layout generation interface
