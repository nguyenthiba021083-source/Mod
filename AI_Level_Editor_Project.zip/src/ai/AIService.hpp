// AI prompt processing interface
