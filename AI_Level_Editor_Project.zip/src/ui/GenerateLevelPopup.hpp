// Generate Level popup skeleton
