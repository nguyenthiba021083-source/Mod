
# AI Mod Factory v3 SaaS Marketplace

## Features
- User system (mock auth)
- Mod generation system
- Marketplace listing
- AI generation endpoint (stub)
- Web dashboard

## Run
cd backend
pip install -r requirements.txt
python app.py

Open:
http://localhost:5000

## Concept
This is a SaaS marketplace version:
- Users create mods
- Mods are stored
- Marketplace lists mods
- AI generates mod logic (placeholder)
