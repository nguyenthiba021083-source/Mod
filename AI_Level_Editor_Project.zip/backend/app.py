
from flask import Flask, request, jsonify, render_template
import json, os, shutil, uuid

app = Flask(__name__)

BASE_TEMPLATE = "factory/template_mod"

def load_db(path):
    with open(path) as f:
        return json.load(f)

def save_db(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

# -------- AUTH (VERY SIMPLE MOCK) --------
@app.route("/api/register", methods=["POST"])
def register():
    db = load_db("backend/db/users.json")
    user = {"id": str(uuid.uuid4()), "email": request.json["email"]}
    db["users"].append(user)
    save_db("backend/db/users.json", db)
    return jsonify(user)

# -------- MOD GENERATION --------
def create_mod(name, mod_id, owner):
    target = f"generated/{owner}_{name}"

    if os.path.exists(target):
        return {"error": "exists"}

    shutil.copytree(BASE_TEMPLATE, target)

    with open(f"{target}/mod.json") as f:
        data = json.load(f)

    data["name"] = name
    data["id"] = mod_id

    with open(f"{target}/mod.json","w") as f:
        json.dump(data,f,indent=2)

    db = load_db("backend/db/mods.json")
    db["mods"].append({
        "name": name,
        "id": mod_id,
        "owner": owner,
        "path": target
    })
    save_db("backend/db/mods.json", db)

    return {"status": "created", "path": target}

@app.route("/api/create_mod", methods=["POST"])
def api_create():
    d = request.json
    return jsonify(create_mod(d["name"], d["id"], d.get("owner","anon")))

# -------- MARKETPLACE --------
@app.route("/api/mods", methods=["GET"])
def list_mods():
    return jsonify(load_db("backend/db/mods.json"))

# -------- AI GENERATOR (placeholder) --------
@app.route("/api/ai_generate", methods=["POST"])
def ai_generate():
    prompt = request.json["prompt"]
    return jsonify({
        "prompt": prompt,
        "result": "Generated pseudo AI mod logic (stub)"
    })

# -------- UI --------
@app.route("/")
def home():
    return render_template("index.html")

if __name__ == "__main__":
    os.makedirs("generated", exist_ok=True)
    app.run(host="0.0.0.0", port=5000, debug=True)
