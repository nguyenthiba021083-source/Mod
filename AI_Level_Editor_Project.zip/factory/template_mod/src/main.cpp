
#include <Geode/Geode.hpp>
using namespace geode::prelude;

$on_mod(Loaded) {
    log::info("SaaS generated mod loaded");
}
